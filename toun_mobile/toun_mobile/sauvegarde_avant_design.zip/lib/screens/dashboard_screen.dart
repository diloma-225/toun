import 'package:flutter/material.dart';

import '../models/dashboard.dart';
import '../services/dashboard_service.dart';
import '../theme/app_theme.dart';
import '../widgets/toun_app_drawer.dart';
import '../widgets/toun_ecran_a_venir.dart';
import '../widgets/toun_logo.dart';
import 'formation_detail_screen.dart';
import 'notifications_screen.dart';
import 'support_chat_screen.dart';

class DashboardScreen extends StatefulWidget {
  final VoidCallback onVoirFormations;
  final VoidCallback onVoirMesFormations;
  final VoidCallback onVoirCertificats;
  final VoidCallback onVoirProfil;

  const DashboardScreen({
    super.key,
    required this.onVoirFormations,
    required this.onVoirMesFormations,
    required this.onVoirCertificats,
    required this.onVoirProfil,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  late Future<TableauDeBord> _futur;

  @override
  void initState() {
    super.initState();
    _futur = DashboardService.instance.charger();
  }

  Future<void> _rafraichir() async {
    final futur = DashboardService.instance.charger();
    setState(() => _futur = futur);
    await futur;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: TounColors.background,
      drawer: TounAppDrawer(
        futurDonnees: _futur,
        onFormations: widget.onVoirFormations,
        onMesFormations: widget.onVoirMesFormations,
        onCertificats: widget.onVoirCertificats,
        onProfil: widget.onVoirProfil,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const SupportChatScreen()),
          );
        },
        backgroundColor: TounColors.teal,
        child: const Icon(Icons.chat_bubble_rounded, color: Colors.white),
      ),
      body: SafeArea(
        child: FutureBuilder<TableauDeBord>(
          future: _futur,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    'Impossible de charger le tableau de bord.\n${snapshot.error}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: TounColors.textSecondary),
                  ),
                ),
              );
            }

            final donnees = snapshot.data!;

            return RefreshIndicator(
              onRefresh: _rafraichir,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                children: [
                  _barreSuperieure(donnees),
                  const SizedBox(height: 18),
                  _enTete(donnees),
                  const SizedBox(height: 20),
                  _grilleStatistiques(donnees),
                  const SizedBox(height: 22),
                  _carteMesFormations(donnees),
                  const SizedBox(height: 22),
                  _sectionTitre('Accès rapides', null, null),
                  const SizedBox(height: 10),
                  _accesRapides(),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _barreSuperieure(TableauDeBord donnees) {
    return Row(
      children: [
        InkWell(
          onTap: () => _scaffoldKey.currentState?.openDrawer(),
          borderRadius: BorderRadius.circular(20),
          child: const Padding(
            padding: EdgeInsets.all(4),
            child: Icon(Icons.menu_rounded, color: TounColors.navy, size: 24),
          ),
        ),
        const SizedBox(width: 10),
        const TounHeaderMark(hauteur: 24),
        const Spacer(),
        IconButton(
          onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const EcranAVenir(
                  titre: 'Mes rendez-vous',
                  icone: Icons.calendar_month_rounded,
                ),
              ),
            );
          },
          icon: const Icon(Icons.calendar_month_rounded, color: TounColors.navy),
        ),
        Stack(
          clipBehavior: Clip.none,
          children: [
            IconButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const NotificationsScreen()),
                );
              },
              icon: const Icon(Icons.notifications_none_rounded, color: TounColors.navy),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(color: Color(0xFFE0523F), shape: BoxShape.circle),
              ),
            ),
          ],
        ),
        const SizedBox(width: 4),
        CircleAvatar(
          radius: 18,
          backgroundColor: TounColors.teal.withValues(alpha: 0.12),
          backgroundImage: donnees.photo.isNotEmpty ? NetworkImage(donnees.photo) : null,
          child: donnees.photo.isEmpty
              ? Text(
                  (donnees.prenom.isNotEmpty ? donnees.prenom[0] : 'T').toUpperCase(),
                  style: const TextStyle(color: TounColors.teal, fontWeight: FontWeight.w700, fontSize: 13),
                )
              : null,
        ),
      ],
    );
  }

  Widget _enTete(TableauDeBord donnees) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Bonjour ${donnees.prenom} 👋', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: TounColors.navy)),
        const SizedBox(height: 3),
        const Text('Votre espace d\'apprentissage TOUN.', style: TextStyle(fontSize: 12.5, color: TounColors.textSecondary)),
      ],
    );
  }

  Widget _grilleStatistiques(TableauDeBord donnees) {
    final tuiles = [
      (icone: Icons.menu_book_rounded, couleur: TounColors.teal, label: 'Mes formations', valeur: '${donnees.totalFormations}'),
      (icone: Icons.play_circle_fill_rounded, couleur: TounColors.blue, label: 'Cours disponibles', valeur: '${donnees.totalFormationsDisponibles}'),
      (icone: Icons.show_chart_rounded, couleur: TounColors.green, label: 'Progression globale', valeur: '${donnees.progressionGlobale}%'),
      (icone: Icons.workspace_premium_rounded, couleur: TounColors.purple, label: 'Certificats', valeur: '${donnees.totalCertificats}'),
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.55,
      children: tuiles.map((tuile) {
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 12, offset: const Offset(0, 6))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(color: tuile.couleur.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
                    child: Icon(tuile.icone, size: 17, color: tuile.couleur),
                  ),
                  const SizedBox(width: 10),
                  Text(tuile.valeur, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: TounColors.navy)),
                ],
              ),
              const SizedBox(height: 8),
              Text(tuile.label, style: const TextStyle(fontSize: 11.5, color: TounColors.textSecondary, fontWeight: FontWeight.w500)),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _carteMesFormations(TableauDeBord donnees) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF18213F), Color(0xFF244D86), Color(0xFF20A1B8)],
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.13), blurRadius: 20, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Continuer ma formation', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Colors.white)),
              if (donnees.formationEnCours != null)
                GestureDetector(
                  onTap: widget.onVoirFormations,
                  child: Text('Voir tout', style: TextStyle(fontSize: 12, color: Colors.white.withValues(alpha: 0.85), fontWeight: FontWeight.w600)),
                ),
            ],
          ),
          const SizedBox(height: 14),
          donnees.formationEnCours != null ? _carteFormationEnCours(donnees.formationEnCours!) : _carteParcoursVide(),
        ],
      ),
    );
  }

  Widget _carteParcoursVide() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 26),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 14, offset: const Offset(0, 6))],
      ),
      child: Column(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(color: TounColors.teal.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(16)),
            child: const Icon(Icons.school_rounded, color: TounColors.teal, size: 26),
          ),
          const SizedBox(height: 14),
          const Text('Votre parcours commence ici', style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: TounColors.navy)),
          const SizedBox(height: 6),
          const Text(
            'Vous n\'avez encore aucune formation. Découvrez le catalogue et choisissez la formation qui correspond à vos objectifs.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: TounColors.textSecondary, height: 1.5),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: widget.onVoirFormations,
            style: ElevatedButton.styleFrom(minimumSize: const Size(0, 44), padding: const EdgeInsets.symmetric(horizontal: 22)),
            child: const Text('Découvrir les formations'),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitre(String titre, String? action, VoidCallback? onAction) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(titre, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: TounColors.navy)),
        if (action != null)
          GestureDetector(
            onTap: onAction,
            child: Text(action, style: const TextStyle(fontSize: 12, color: TounColors.teal, fontWeight: FontWeight.w600)),
          ),
      ],
    );
  }

  Widget _carteFormationEnCours(FormationEnCours formation) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => FormationDetailScreen(idForm: formation.idForm)),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 14, offset: const Offset(0, 6))],
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: formation.image.isNotEmpty
                  ? Image.network(formation.image, width: 56, height: 56, fit: BoxFit.cover)
                  : Container(
                      width: 56,
                      height: 56,
                      color: TounColors.teal.withValues(alpha: 0.12),
                      child: const Icon(Icons.menu_book_rounded, color: TounColors.teal),
                    ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(formation.titre, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, color: TounColors.navy)),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: formation.progression / 100,
                      minHeight: 6,
                      backgroundColor: TounColors.background,
                      valueColor: const AlwaysStoppedAnimation(TounColors.teal),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('${formation.progression}%', style: const TextStyle(fontSize: 11, color: TounColors.textSecondary)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 34,
              height: 34,
              decoration: const BoxDecoration(color: TounColors.teal, shape: BoxShape.circle),
              child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 17),
            ),
          ],
        ),
      ),
    );
  }

  Widget _accesRapides() {
    final elements = [
      (icone: Icons.menu_book_rounded, couleur: TounColors.blue, label: 'Formations', onTap: widget.onVoirFormations),
      (icone: Icons.workspace_premium_rounded, couleur: TounColors.purple, label: 'Certificats', onTap: widget.onVoirCertificats),
      (
        icone: Icons.fact_check_rounded,
        couleur: TounColors.teal,
        label: 'Évaluations',
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => const EcranAVenir(
                titre: 'Mes évaluations',
                icone: Icons.fact_check_rounded,
              ),
            ),
          );
        },
      ),
      (icone: Icons.person_rounded, couleur: TounColors.blue, label: 'Profil', onTap: widget.onVoirProfil),
    ];

    return GridView.count(
      crossAxisCount: 4,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12,
      crossAxisSpacing: 10,
      children: elements.map((e) {
        return GestureDetector(
          onTap: e.onTap,
          child: Column(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(color: e.couleur.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(14)),
                child: Icon(e.icone, color: e.couleur),
              ),
              const SizedBox(height: 6),
              Text(e.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, color: TounColors.textSecondary)),
            ],
          ),
        );
      }).toList(),
    );
  }
}
