import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/formation.dart';
import '../services/lecon_service.dart';
import '../theme/app_theme.dart';
import '../widgets/toun_button.dart';

class LessonScreen extends StatefulWidget {
  final int idForm;
  final String titreFormation;
  final List<ModuleFormation> modules;
  final Lecon leconInitiale;

  const LessonScreen({
    super.key,
    required this.idForm,
    required this.titreFormation,
    required this.modules,
    required this.leconInitiale,
  });

  @override
  State<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends State<LessonScreen> {
  late Lecon _leconActive;
  late Future<ContenuLecon> _futurContenu;
  final Set<int> _leconsTerminees = {};
  int _moduleOuvert = 0;

  int get _totalLecons => widget.modules.fold(0, (total, m) => total + m.lecons.length);

  @override
  void initState() {
    super.initState();
    _leconActive = widget.leconInitiale;
    _futurContenu = LeconService.instance.contenu(_leconActive.idLecon);

    for (var i = 0; i < widget.modules.length; i++) {
      if (widget.modules[i].lecons.any((l) => l.idLecon == _leconActive.idLecon)) {
        _moduleOuvert = i;
        break;
      }
    }
  }

  void _ouvrirLecon(Lecon lecon) {
    setState(() {
      _leconActive = lecon;
      _futurContenu = LeconService.instance.contenu(lecon.idLecon);
    });
  }

  Future<void> _marquerTerminee() async {
    setState(() => _leconsTerminees.add(_leconActive.idLecon));

    final pourcentage = _totalLecons == 0 ? 100 : ((_leconsTerminees.length / _totalLecons) * 100).round();

    try {
      await LeconService.instance.majProgression(widget.idForm, pourcentage);
    } catch (_) {
      // La progression sera resynchronisée à la prochaine ouverture de la formation.
    }

    final toutesLecons = widget.modules.expand((m) => m.lecons).toList();
    final indexActuel = toutesLecons.indexWhere((l) => l.idLecon == _leconActive.idLecon);

    if (indexActuel != -1 && indexActuel < toutesLecons.length - 1) {
      _ouvrirLecon(toutesLecons[indexActuel + 1]);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vous avez terminé toutes les leçons de cette formation. 🎉')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: TounColors.navy,
        title: Text(widget.titreFormation, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: TounColors.navy, fontSize: 15, fontWeight: FontWeight.w700)),
      ),
      body: Column(
        children: [
          _lecteurVideo(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                FutureBuilder<ContenuLecon>(
                  future: _futurContenu,
                  builder: (context, snapshot) {
                    final titre = snapshot.data?.titre ?? _leconActive.titre;
                    final contenu = snapshot.data?.contenu ?? '';

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(titre, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: TounColors.navy)),
                        if (contenu.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(contenu, style: const TextStyle(color: TounColors.textSecondary, height: 1.6)),
                        ],
                        const SizedBox(height: 16),
                        TounButton(texte: 'Marquer comme terminée →', onPressed: _marquerTerminee),
                      ],
                    );
                  },
                ),
                const SizedBox(height: 26),
                const Text('Modules', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: TounColors.navy)),
                const SizedBox(height: 10),
                ...List.generate(widget.modules.length, (index) => _carteModule(index)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _lecteurVideo() {
    return Container(
      width: double.infinity,
      height: 210,
      decoration: const BoxDecoration(color: TounColors.navy),
      child: FutureBuilder<ContenuLecon>(
        future: _futurContenu,
        builder: (context, snapshot) {
          final video = snapshot.data?.video ?? '';

          return Center(
            child: InkWell(
              onTap: video.isEmpty
                  ? null
                  : () => launchUrl(Uri.parse(video), mode: LaunchMode.externalApplication),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.15), shape: BoxShape.circle),
                    child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 34),
                  ),
                  if (video.isEmpty) ...[
                    const SizedBox(height: 10),
                    const Text('Vidéo bientôt disponible', style: TextStyle(color: Colors.white70, fontSize: 12)),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _carteModule(int index) {
    final module = widget.modules[index];
    final ouvert = index == _moduleOuvert;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: TounColors.background, borderRadius: BorderRadius.circular(14)),
      child: Column(
        children: [
          InkWell(
            onTap: () => setState(() => _moduleOuvert = ouvert ? -1 : index),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Expanded(child: Text('Module ${index + 1} : ${module.titre}', style: const TextStyle(fontWeight: FontWeight.w700, color: TounColors.navy))),
                  Icon(ouvert ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: TounColors.gray),
                ],
              ),
            ),
          ),
          if (ouvert)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
              child: Column(
                children: module.lecons.map((lecon) {
                  final active = lecon.idLecon == _leconActive.idLecon;
                  final terminee = _leconsTerminees.contains(lecon.idLecon);

                  return InkWell(
                    onTap: () => _ouvrirLecon(lecon),
                    borderRadius: BorderRadius.circular(10),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(
                            terminee ? Icons.check_circle_rounded : (active ? Icons.play_circle_fill_rounded : Icons.play_circle_outline_rounded),
                            size: 18,
                            color: terminee ? TounColors.green : (active ? TounColors.teal : TounColors.gray),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              lecon.titre,
                              style: TextStyle(fontSize: 12.5, fontWeight: active ? FontWeight.w700 : FontWeight.w500, color: active ? TounColors.navy : TounColors.textSecondary),
                            ),
                          ),
                          if (lecon.duree != null) Text(lecon.duree!, style: const TextStyle(fontSize: 11, color: TounColors.textSecondary)),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }
}
